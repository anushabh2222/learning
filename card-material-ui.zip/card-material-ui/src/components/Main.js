
import { Box, Card, CardContent, Typography,CardActions,CardMedia,Button } from '@mui/material'

const Main = () => {
    return (

        <Box width="300px" align="left" >
            <Card>
                <CardMedia component='img' height='140' image="https://5wbts45dnuj11q6172p5dkzf-wpengine.netdna-ssl.com/wp-content/uploads/2021/05/shutterstock_664284277-1000x667-1.jpg" alt="software"/>
                <CardContent>
                    <Typography gutterBottom variant='h5' component='div'>
                        React
                    </Typography>
                    <Typography variant='body2' color='text.secondary'> {/*body 2 for the text font and design */}
                    software, instructions that tell a computer what to do. Software comprises the entire set of programs, procedures, and routines associated with the operation of a computer system. The term was coined to differentiate these instructions from hardware i.e., the physical components of a computer system.
                    </Typography>

                </CardContent>
                <CardActions>
                    <Button>
                     Share
                    </Button>
                    <Button>
                    Learn more
                    </Button>
                </CardActions>
            </Card>
        </Box>

    )
}
export default Main;
